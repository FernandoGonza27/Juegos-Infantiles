
package ProyectoTerminado;
import ProyectoTerminado.Jugadores;
import java.io.*;
import static ProyectoTerminado.Jugadores.Jugador;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import javax.swing.JLabel;


public class Data {    
    static ArrayList<Jugadores>Jugador_list2=new ArrayList();
    
    public  void crear() {
        System.out.println("Hola ="+Jugador.size());
        PrintWriter writer = null;
        
        try {        
        writer = new PrintWriter(new BufferedWriter(new FileWriter("Jugadores.txt",true)));        
        writer.println(Jugador.get(0).getNombre() +"-"+Jugador.get(0).getPuntos()+"-"+Jugador.get(0).getFecha()+"-"+Jugador.get(0).getHora());        
        writer.println(Jugador.get(1).getNombre() +"-"+Jugador.get(1).getPuntos()+"-"+Jugador.get(1).getFecha()+"-"+Jugador.get(1).getHora());
        Jugador.remove(0);
        Jugador.remove(1);
                        
        writer.close();;
        
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Error al escribir el archivo");
        }
        
    }

    public void leerArchivo1() throws FileNotFoundException, IOException {                           
        try{ 
        Jugador_list2.clear();
        BufferedReader reader = new BufferedReader(new FileReader("Jugadores.txt"));
        String s = new String();
        String nombre;
        String puntos;
        String fecha,hora;
        while ((s = reader.readLine()) != null) {
            Jugadores jugador = new Jugadores();                
                String[] data = s.split("-");
                nombre = data[0];
                puntos = data[1];
                fecha = data[2];
                hora = data[3];
                jugador.setNombre(nombre);
                jugador.setPuntos(puntos);
                jugador.setFecha(fecha);
                jugador.setHora(hora);
                Jugador_list2.add(jugador);                
        }
        reader.close();
        } catch (java.io.IOException e) {
            JOptionPane.showMessageDialog(null, "error al leer el archivo");
        }

    
   }
    
    
     
    
}
