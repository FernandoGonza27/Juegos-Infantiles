
package ProyectoTerminado;
import java.util.ArrayList;

public class player {
    protected String name,difficulty;
    protected int letters;
    protected int life;
    protected int points;
    protected int finallife;
    protected String hiddenword;
    static ArrayList<player>players_list = new ArrayList();
    static ArrayList<player>players_list2 = new ArrayList();
    public player (){
        this.name = "";
        this.difficulty = "";
        this.letters = 0;
        this.life = 0;
        this.finallife = 0;
        this.points = 0;
        this.hiddenword = "";
    }
    public player(String name,String difficulty,int letters,String hiddenword,int finallife){
        this.name = name;
        this.difficulty = difficulty;
        this.letters = letters;
        this.life = life;
        this.hiddenword = hiddenword;
        this.finallife = finallife;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    public int getLetters() {
        return letters;
    }

    public void setLetters(int letters) {
        this.letters = letters;
    }

    public int getLife() {
        return life;
    }

    public void setLife(int life) {
        this.life = life;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public String getHiddenword() {
        return hiddenword;
    }

    public void setHiddenword(String hiddenword) {
        this.hiddenword = hiddenword;
    }

    public int getFinallife() {
        return finallife;
    }

    public void setFinallife(int finallife) {
        this.finallife = finallife;
    }
    
    public void loselife(){
        int index = players_list.size()-1;
        int lifeaux = players_list.get(index).getLife()-1;
        players_list.get(index).setLife(lifeaux);
    }
    public void earnPoints(){
        int index = players_list.size()-1;
        int point = players_list.get(index).getPoints();
        int pointaux = point+1;
        players_list.get(index).setPoints(pointaux);
    }
    public void new_player(String name,String difficulty,int letters,int life,String hiddenword){
        player player1 = new player();
        player1.setName(name);
        player1.setDifficulty(difficulty);
        player1.setLetters(letters);
        player1.setLife(life);
        player1.setHiddenword(hiddenword);
        player1.setFinallife(life);
        players_list.add(player1);
        
    }
}
