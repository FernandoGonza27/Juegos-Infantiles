/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProyectoTerminado;
import ProyectoTerminado.Ganador;
import ProyectoTerminado.Empate;
import ProyectoTerminado.Data;

import java.awt.Color;
import javax.swing.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.ImageIcon;
import static ProyectoTerminado.Jugadores.Jugador;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author huawei
 */
public class Juego extends javax.swing.JDialog {
    int turno =1;
    int puntos=0,puntos2=0;
    boolean pase = true;
    Jugadores global= new Jugadores();
    public Juego(javax.swing.JDialog  parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setLocationRelativeTo(null);
        datos();
        
      
        }
    public void ganador(){
        //Columnas        
        verificacion(bnt1, bnt2, bnt3);
        verificacion(bnt4, bnt5, bnt6);
        verificacion(bnt7, bnt8, bnt9);
        
        //Filas
        verificacion(bnt1, bnt4, bnt7);
        verificacion(bnt2, bnt5, bnt8);
        verificacion(bnt3, bnt6, bnt9);
        
        //Diagonal principal
        verificacion(bnt1, bnt5, bnt9);
        
        //Diagonal secundaria
        verificacion(bnt3, bnt5, bnt7);
        
    }
    public void verificacion(JButton A1,JButton A2,JButton A3){
        String condi_1=A1.getText();
        String condi_2=A2.getText();
        String condi_3=A3.getText();
        if (condi_1=="x"&&condi_2=="x"&&condi_3=="x") {
         pase= false;
        puntos=Integer.parseInt(txtP1.getText());
        puntos=puntos*2; 
        Jugador.get(0).setPuntos(Integer.toString(puntos));
        txtP1.setText(Integer.toString(puntos));

         A1.setIcon(new ImageIcon("ganador.jpg"));
         A2.setIcon(new ImageIcon("ganador.jpg"));
         A3.setIcon(new ImageIcon("ganador.jpg"));         
         
         String nombre=Jugador.get(0).getNombre();
         String puntos=Jugador.get(0).getPuntos();
         global.agregaGanador(nombre,puntos);
         Ganador ventanaGanador= new Ganador(new javax.swing.JDialog(),true);         
         ventanaGanador.setVisible(true);
         
       
        }else if(condi_1=="O"&&condi_2=="O"&&condi_3=="O"){
         pase=false;
         puntos2=Integer.parseInt(txtP2.getText());
         puntos2=puntos2*2; 
         Jugador.get(1).setPuntos(Integer.toString(puntos2));
         txtP2.setText(Integer.toString(puntos2));

         A1.setIcon(new ImageIcon("ganador.jpg"));
         A2.setIcon(new ImageIcon("ganador.jpg"));
         A3.setIcon(new ImageIcon("ganador.jpg"));         
         String nombre=Jugador.get(1).getNombre();
         String puntos=Jugador.get(1).getPuntos();
         global.agregaGanador(nombre,puntos);
         
         Ganador ventanaGanador= new Ganador(new javax.swing.JDialog(),true);         
         ventanaGanador.setVisible(true);
         
         
         
         
        
        }
        
    }
    
    
    public void turno(JButton A1){
        String condi=A1.getText();
        if(condi==""){
            if (turno==1) {
                A1.setText("x");
                A1.setIcon(new ImageIcon("Jugador1.jpg"));
                turno=2;
                puntos=Integer.parseInt(txtP1.getText());
                puntos=puntos+1; 
                Jugador.get(0).setPuntos(Integer.toString(puntos));
                txtP1.setText(Integer.toString(puntos));
                
                
            }else if(turno==2){
                A1.setText("O");
                A1.setIcon(new ImageIcon("Jugador2.jpg"));
                turno=1;
                puntos2=Integer.parseInt(txtP2.getText());
                puntos2=puntos2+1; 
                Jugador.get(1).setPuntos(Integer.toString(puntos2));
                txtP2.setText(Integer.toString(puntos2));
            }
        }
    }
    public void Empata(){
        if(pase==true){            
        JButton []arrBtn = new JButton[9];
        arrBtn[0]=bnt1;arrBtn[1]=bnt2;arrBtn[2]=bnt3;
        arrBtn[3]=bnt4;arrBtn[4]=bnt5;arrBtn[5]=bnt6;
        arrBtn[6]=bnt7;arrBtn[7]=bnt8;arrBtn[8]=bnt9;
        
        String condi;
        String []valores=new String[arrBtn.length];
        int contador=0;
        int contador2=0;
        for (int i =0; i < arrBtn.length; i++) {
           condi=arrBtn[i].getText();
           valores[i]=condi;
           
        }
        for (int j = 0; j <valores.length; j++) {                
           if (valores[j]=="x") {
              contador+=1;  
               if (contador>=5) {
                    Empate  ventanaEmpatados= new Empate(new javax.swing.JDialog(),true);         
                    ventanaEmpatados.setVisible(true);
                    pase=true;
                   
                    
         
               }
            }else if(valores[j]=="O"){
              contador2+=1;
              if (contador2>=5) {
                   Empate  ventanaEmpatados= new Empate(new javax.swing.JDialog(),true);         
                    ventanaEmpatados.setVisible(true);
                    pase=true;
                    
                  
                  
         
               }
            }
              
        }    
        }
    }
    public void reiniciar(){
        pase=true;
        JOptionPane.showMessageDialog(rootPane,"El Juego se esta reiniciando......");
        JOptionPane.showMessageDialog(rootPane,"Comienza Jugador que perdio");
        puntos=0;puntos2=0;        
        txtP1.setText(Integer.toString(puntos));
        txtP2.setText(Integer.toString(puntos));
        JButton []arrBtn = new JButton[9];
        arrBtn[0]=bnt1;arrBtn[1]=bnt2;arrBtn[2]=bnt3;
        arrBtn[3]=bnt4;arrBtn[4]=bnt5;arrBtn[5]=bnt6;
        arrBtn[6]=bnt7;arrBtn[7]=bnt8;arrBtn[8]=bnt9;
        
        for (int i =0; i < arrBtn.length; i++) {
           arrBtn[i].setText("");
           arrBtn[i].setIcon(null);
        }
    }
    public  void datos(){   
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss");
        String h=dtf.format(LocalDateTime.now());
        txtHora.setText(h);
        
        DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        String f=dtf1.format(LocalDateTime.now());
        txtFecha.setText(f);
        
        lblNom1.setText(Jugador.get(0).getNombre());
        lblNom2.setText(Jugador.get(1).getNombre());
        
    
    }
    public void  finalizar(){
    Data proceso= new Data();        
    proceso.crear();       
         
    
   
    
    
    }
    
    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        bnt4 = new javax.swing.JButton();
        bnt1 = new javax.swing.JButton();
        bnt6 = new javax.swing.JButton();
        bnt2 = new javax.swing.JButton();
        bnt5 = new javax.swing.JButton();
        bnt9 = new javax.swing.JButton();
        bnt7 = new javax.swing.JButton();
        bnt8 = new javax.swing.JButton();
        lblNom1 = new javax.swing.JLabel();
        lblNom2 = new javax.swing.JLabel();
        txtP2 = new javax.swing.JTextField();
        txtP1 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        lblFecha = new javax.swing.JLabel();
        btnReiniciar = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();
        txtFecha = new javax.swing.JTextField();
        txtHora = new javax.swing.JTextField();
        bnt3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.red, java.awt.Color.red, java.awt.Color.red, java.awt.Color.red));

        bnt4.setBackground(new java.awt.Color(0, 0, 0));
        bnt4.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        bnt4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt4ActionPerformed(evt);
            }
        });

        bnt1.setBackground(new java.awt.Color(0, 0, 0));
        bnt1.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        bnt1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt1ActionPerformed(evt);
            }
        });

        bnt6.setBackground(new java.awt.Color(0, 0, 0));
        bnt6.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        bnt6.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt6ActionPerformed(evt);
            }
        });

        bnt2.setBackground(new java.awt.Color(0, 0, 0));
        bnt2.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        bnt2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt2ActionPerformed(evt);
            }
        });

        bnt5.setBackground(new java.awt.Color(0, 0, 0));
        bnt5.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        bnt5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt5ActionPerformed(evt);
            }
        });

        bnt9.setBackground(new java.awt.Color(0, 0, 0));
        bnt9.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        bnt9.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt9ActionPerformed(evt);
            }
        });

        bnt7.setBackground(new java.awt.Color(0, 0, 0));
        bnt7.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        bnt7.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt7ActionPerformed(evt);
            }
        });

        bnt8.setBackground(new java.awt.Color(0, 0, 0));
        bnt8.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        bnt8.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt8ActionPerformed(evt);
            }
        });

        lblNom1.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        lblNom1.setForeground(new java.awt.Color(255, 255, 255));
        lblNom1.setText("Jugador1");
        lblNom1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));

        lblNom2.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        lblNom2.setForeground(new java.awt.Color(255, 255, 255));
        lblNom2.setText("Jugador2");
        lblNom2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));

        txtP2.setEditable(false);
        txtP2.setBackground(new java.awt.Color(0, 0, 0));
        txtP2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        txtP2.setForeground(new java.awt.Color(255, 255, 255));
        txtP2.setText("0");
        txtP2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));

        txtP1.setEditable(false);
        txtP1.setBackground(new java.awt.Color(0, 0, 0));
        txtP1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        txtP1.setForeground(new java.awt.Color(255, 255, 255));
        txtP1.setText("0");
        txtP1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));

        jLabel3.setBackground(new java.awt.Color(0, 0, 0));
        jLabel3.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Hora:");
        jLabel3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));

        lblFecha.setBackground(new java.awt.Color(0, 0, 0));
        lblFecha.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        lblFecha.setForeground(new java.awt.Color(255, 255, 255));
        lblFecha.setText("Fecha:");
        lblFecha.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));

        btnReiniciar.setBackground(new java.awt.Color(0, 0, 0));
        btnReiniciar.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        btnReiniciar.setForeground(new java.awt.Color(255, 255, 255));
        btnReiniciar.setText("Reiniciar");
        btnReiniciar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        btnReiniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReiniciarActionPerformed(evt);
            }
        });

        btnVolver.setBackground(new java.awt.Color(0, 0, 0));
        btnVolver.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        btnVolver.setForeground(new java.awt.Color(255, 255, 255));
        btnVolver.setText("Volver a menu ");
        btnVolver.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });

        txtFecha.setEditable(false);
        txtFecha.setBackground(new java.awt.Color(0, 0, 0));
        txtFecha.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        txtFecha.setForeground(new java.awt.Color(255, 255, 255));
        txtFecha.setText("0");
        txtFecha.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));

        txtHora.setEditable(false);
        txtHora.setBackground(new java.awt.Color(0, 0, 0));
        txtHora.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        txtHora.setForeground(new java.awt.Color(255, 255, 255));
        txtHora.setText("0");
        txtHora.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));

        bnt3.setBackground(new java.awt.Color(0, 0, 0));
        bnt3.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        bnt3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(135, 135, 135)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(bnt1, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bnt2, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bnt3, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addComponent(bnt7, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(bnt8, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(bnt9, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addComponent(bnt4, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(bnt5, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(bnt6, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(219, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblFecha, javax.swing.GroupLayout.DEFAULT_SIZE, 45, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtHora, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnReiniciar, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblNom1, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblNom2, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtP2, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                            .addComponent(txtP1))))
                .addGap(32, 32, 32))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(48, 48, 48)
                    .addComponent(btnVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(473, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblNom1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(txtP1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtP2, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblNom2, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtHora, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(65, 65, 65)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(bnt2, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bnt1, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(bnt4, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(bnt6, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(bnt9, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(bnt7, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(bnt5, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(bnt8, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 49, Short.MAX_VALUE)
                        .addComponent(btnReiniciar))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(bnt3, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                    .addContainerGap(473, Short.MAX_VALUE)
                    .addComponent(btnVolver)
                    .addGap(1, 1, 1)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    
    
    
    
    private void btnReiniciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReiniciarActionPerformed
    reiniciar();
    }//GEN-LAST:event_btnReiniciarActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
    this.dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    private void bnt1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt1ActionPerformed
        turno(bnt1);
        ganador();
        Empata();
        
        
     
    }//GEN-LAST:event_bnt1ActionPerformed

    private void bnt2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt2ActionPerformed
        turno(bnt2);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt2ActionPerformed

    private void bnt4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt4ActionPerformed
        turno(bnt4);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt4ActionPerformed

    private void bnt5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt5ActionPerformed
        turno(bnt5);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt5ActionPerformed

    private void bnt6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt6ActionPerformed
        turno(bnt6);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt6ActionPerformed

    private void bnt7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt7ActionPerformed
        turno(bnt7);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt7ActionPerformed

    private void bnt8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt8ActionPerformed
        turno(bnt8);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt8ActionPerformed

    private void bnt9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt9ActionPerformed
        turno(bnt9);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt9ActionPerformed

    private void bnt3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt3ActionPerformed
        turno(bnt3);
        ganador();
    }//GEN-LAST:event_bnt3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Juego.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Juego.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Juego.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Juego.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {                
                Juego dialog = new Juego(new javax.swing.JDialog (), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bnt1;
    private javax.swing.JButton bnt2;
    private javax.swing.JButton bnt3;
    private javax.swing.JButton bnt4;
    private javax.swing.JButton bnt5;
    private javax.swing.JButton bnt6;
    private javax.swing.JButton bnt7;
    private javax.swing.JButton bnt8;
    private javax.swing.JButton bnt9;
    private javax.swing.JButton btnReiniciar;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblFecha;
    private javax.swing.JLabel lblNom1;
    private javax.swing.JLabel lblNom2;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtHora;
    private javax.swing.JTextField txtP1;
    private javax.swing.JTextField txtP2;
    // End of variables declaration//GEN-END:variables
}
