/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProyectoTerminado;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Date;
import java.text.SimpleDateFormat;
import javax.swing.JPanel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Arrays;
import java.util.List;
/*
These are all the libraries that were imported for this workThese are all the libraries that were imported for this work
*/

public class Snake extends javax.swing.JFrame implements KeyListener  {
    int culebra = -1;
    boolean valido=true, activado=false, co=false;
    int direccion, puntos=0, contador;
    Point ultimo;
    int x,y;
    String jugadorX;
    File archivosDatos;
    FileWriter escribir;
    PrintWriter insertarLinea;
    /*
    All variables were defined here 
    */
    public Snake() {
        /*
        This is the main method where the Snake is created.
        */
        initComponents();
        String basePath = new File("").getAbsolutePath();
        archivosDatos = new File(basePath + "\\src\\main\\java\\ProyectoTerminado\\puntosSnake.txt");//Here you save the player's data, points and date in the files.
        this.setLocationRelativeTo(null);
        nombreJugador();
        lbFecha.setText(fecha());
        setSize(1000,800);
        //Start to create the snake directions
        do {
            x=(int)Math.floor(Math.random()*20);
            y=(int)Math.floor(Math.random()*20);
            valido=false;
        /*
          Here you define the size of the game, and also create the snake's head.
        */    
        } while(valido);
        jPanel1.setBounds(0, 0, 800, 780);
        JButton cabeza = new JButton();
        List<JButton> serp = new ArrayList<>();
        List<Point> partesSerp = new ArrayList<>();
        cabeza.setBounds(x*20, y*20, 20, 20);
        cabeza.setContentAreaFilled(false);
        cabeza.setOpaque(true);
        cabeza.setBackground(new Color(0,0,0));
        cabeza.addKeyListener(this);
        jPanel1.add(cabeza);// Here define the snake head
        /*
        Here you define the size of the meal 
        */
        JButton comida = new JButton();
        comida.setBounds(x*20, y*20, 20, 20);
        comida.setContentAreaFilled(false);
        comida.setOpaque(true);
        comida.setBackground(new Color(255,45,0));
        comida.addKeyListener(this);
        jPanel1.add(comida);
        jPanel1.addKeyListener(this);
        //Here are the necessary snake and food settings
        Timer p=new Timer();
        
        TimerTask movimiento = new TimerTask(){
            @Override
            public void run() {
                co=false;
                contador=0;
                jLabel1.setText("Puntos "+puntos );
                partesSerp.add(cabeza.getLocation());
                activado=false;
                int tamaño=partesSerp.size();
                for(int i = 0; i <=tamaño-1; i++){
                    if(partesSerp.size()==serp.size()){
                        break;
                    }
                    partesSerp.remove(0);
                }
                //Here are the activation of the point counter and the snake
                switch(direccion){
                    case 1:
                        cabeza.setLocation(cabeza.getX()+20, cabeza.getY());
                        if(cabeza.getX()>=comida.getX()&&cabeza.getX()<=comida.getX()+20){
                            if(cabeza.getY()>=comida.getY()&&cabeza.getY()<=comida.getY()+20){
                                partesSerp.add(cabeza.getLocation());
                                serp.add(new JButton());
                                culebra++;
                                serp.get(culebra).setContentAreaFilled(false);
                                serp.get(culebra).setOpaque(true);
                                serp.get(culebra).setBounds(new Rectangle(partesSerp.get(culebra), new Dimension(20,20)));
                                serp.get(culebra).setBackground(new Color(91, 44, 111));
                                jPanel1.add(serp.get(culebra));
                                
                                do {
                                    for(int e = 0; e <= serp.size()-1; e++){
                                        x=(int)Math.floor(Math.random()*20);
                                        y=(int)Math.floor(Math.random()*20);
                                        
                                        valido = (new Point(x*20,y*20).equals(serp.get(e).getLocation()));
                                        if(!valido)break;
                                    }
                                } while(valido);
                                comida.setLocation(x*20,y*20);
                                puntos++;
                                co=true;
                            }
                        }
                        break;
                        
                    case 2:
                        cabeza.setLocation(cabeza.getX()-20, cabeza.getY());
                        if(cabeza.getX()>=comida.getX()&&cabeza.getX()<=comida.getX()+20){
                            if(cabeza.getY()>=comida.getY()&&cabeza.getY()<=comida.getY()+20){
                                partesSerp.add(cabeza.getLocation());
                                serp.add(new JButton());
                                culebra++;
                                serp.get(culebra).setContentAreaFilled(false);
                                serp.get(culebra).setOpaque(true);
                                serp.get(culebra).setBounds(new Rectangle(partesSerp.get(culebra), new Dimension(20,20)));
                                serp.get(culebra).setBackground(new Color(91, 44, 111));
                                jPanel1.add(serp.get(culebra));
                                
                                do {
                                    for(int e = 0; e <= serp.size()-1; e++){
                                        x=(int)Math.floor(Math.random()*20);
                                        y=(int)Math.floor(Math.random()*20);
                                        
                                        valido = (new Point(x*20,y*20).equals(serp.get(e).getLocation()));
                                        if(!valido)break;
                                    }
                                } while(valido);
                                comida.setLocation(x*20,y*20);
                                puntos++;
                                co=true;
                            }
                        }
                        break;
                        
                    case 3:
                        cabeza.setLocation(cabeza.getX(), cabeza.getY()+20);
                        if(cabeza.getX()>=comida.getX()&&cabeza.getX()<=comida.getX()+20){
                            if(cabeza.getY()>=comida.getY()&&cabeza.getY()<=comida.getY()+20){
                                partesSerp.add(cabeza.getLocation());
                                serp.add(new JButton());
                                culebra++;
                                serp.get(culebra).setContentAreaFilled(false);
                                serp.get(culebra).setOpaque(true);
                                serp.get(culebra).setBounds(new Rectangle(partesSerp.get(culebra), new Dimension(20,20)));
                                serp.get(culebra).setBackground(new Color(91, 44, 111));
                                jPanel1.add(serp.get(culebra));
                                
                                do {
                                    for(int e = 0; e <= serp.size()-1; e++){
                                        x=(int)Math.floor(Math.random()*20);
                                        y=(int)Math.floor(Math.random()*20);
                                        
                                        valido = (new Point(x*20,y*20).equals(serp.get(e).getLocation()));
                                        if(!valido)break;
                                    }
                                } while(valido);
                                comida.setLocation(x*20,y*20);
                                puntos++;
                                co=true;
                            }
                        }
                        break;
                        
                    case 4:
                        cabeza.setLocation(cabeza.getX(), cabeza.getY()-20);
                        if(cabeza.getX()>=comida.getX()&&cabeza.getX()<=comida.getX()+20){
                            if(cabeza.getY()>=comida.getY()&&cabeza.getY()<=comida.getY()+20){
                                partesSerp.add(cabeza.getLocation());
                                serp.add(new JButton());
                                culebra++;
                                serp.get(culebra).setContentAreaFilled(false);
                                serp.get(culebra).setOpaque(true);
                                serp.get(culebra).setBounds(new Rectangle(partesSerp.get(culebra), new Dimension(20,20)));
                                serp.get(culebra).setBackground(new Color(91, 44, 111));
                                jPanel1.add(serp.get(culebra));
                                
                                do {
                                    for(int e = 0; e <= serp.size()-1; e++){
                                        x=(int)Math.floor(Math.random()*20);
                                        y=(int)Math.floor(Math.random()*20);
                                        
                                        valido = (new Point(x*20,y*20).equals(serp.get(e).getLocation()));
                                        if(!valido)break;
                                    }
                                } while(valido);
                                comida.setLocation(x*20,y*20);
                                puntos++;
                                co=true;
                            }
                        }
                        break;
                }
                //All those options of the "Switch" are the different directions of the snake
                //together with the validation that if it ate the food the game continues
                for(int i = 0; i <=partesSerp.size()-1; i++){
                    if(cabeza.getLocation().equals(partesSerp.get(i))){
                        contador++;
                        if(co){
                            if(contador==2){
                                JOptionPane.showMessageDialog(null, "Fin has colisonado tus puntos son: "+puntos);
                                if(!archivosDatos.exists()){
                                    try{
                                        JOptionPane.showMessageDialog(null, "Se han guardado tus datos ");
                                        archivosDatos.createNewFile();
                                        escribir = new FileWriter(archivosDatos,true);
                                        insertarLinea = new PrintWriter(escribir);
                                        insertarLinea.print("Los puntos de "+jugadorX+ " son "+puntos+"\n");
                                        insertarLinea.print("Fecha en la que se jugo: "+fecha()+"\n");
                                        insertarLinea.print("-------------------------------------------------"+"\n");
                                        escribir.close();
                                        System.exit(0);
                                        
                                    } catch(Exception e){
                                        e.printStackTrace();
                                    }
                                }else{
                                    try{
                                        JOptionPane.showMessageDialog(null, "Se han guardados nuevos datos ");
                                        archivosDatos.createNewFile();
                                        escribir = new FileWriter(archivosDatos,true);
                                        insertarLinea = new PrintWriter(escribir);
                                        insertarLinea.print("Los puntos de "+jugadorX+ " son "+puntos+"\n");
                                        insertarLinea.print("Fecha en la que se jugo: "+fecha()+"\n");
                                        insertarLinea.print("-------------------------------------------------"+"\n");
                                        escribir.close();
                                        System.exit(0);
                                        
                                    } catch(Exception e){
                                        e.printStackTrace();
                                    }
                                }
                            }
                        }else {
                                JOptionPane.showMessageDialog(null, "Fin has colisonado tus puntos son: "+puntos);
                                if(!archivosDatos.exists()){
                                    try{
                                        JOptionPane.showMessageDialog(null, "Se han guardado tus datos ");
                                        archivosDatos.createNewFile();
                                        escribir = new FileWriter(archivosDatos,true);
                                        insertarLinea = new PrintWriter(escribir);
                                        insertarLinea.print("Los puntos de "+jugadorX+ " son "+puntos+"\n");
                                        insertarLinea.print("Fecha en la que se jugo: "+fecha()+"\n");
                                        insertarLinea.print("-------------------------------------------------"+"\n");
                                        escribir.close();
                                        System.exit(0);
                                        
                                    } catch(Exception e){
                                        e.printStackTrace();
                                    }
                                }else{
                                    try{
                                        JOptionPane.showMessageDialog(null, "Se han guardados nuevos datos ");
                                        archivosDatos.createNewFile();
                                        escribir = new FileWriter(archivosDatos,true);
                                        insertarLinea = new PrintWriter(escribir);
                                        insertarLinea.print("Los puntos de "+jugadorX+ " son "+puntos+"\n");
                                        insertarLinea.print("Fecha en la que se jugo: "+fecha()+"\n");
                                        insertarLinea.print("-------------------------------------------------"+"\n");
                                        escribir.close();
                                        System.exit(0);
                                        
                                    } catch(Exception e){
                                        e.printStackTrace();
                                    }
                                }
                            }
                    }   
                }
                
                for(int i = 0; i <=serp.size()-1; i++){
                    serp.get(i).setLocation(partesSerp.get(i));
                }
                if(cabeza.getLocation().getX()>=500){
                    JOptionPane.showMessageDialog(null, "Fin has colisionado tus puntos son: "+puntos);
                    if(!archivosDatos.exists()){
                                    try{
                                        JOptionPane.showMessageDialog(null, "Se han guardado tus datos ");
                                        archivosDatos.createNewFile();
                                        escribir = new FileWriter(archivosDatos,true);
                                        insertarLinea = new PrintWriter(escribir);
                                        insertarLinea.print("Los puntos de "+jugadorX+ " son "+puntos+"\n");
                                        insertarLinea.print("Fecha en la que se jugo: "+fecha()+"\n");
                                        insertarLinea.print("-------------------------------------------------"+"\n");
                                        escribir.close();
                                        System.exit(0);
                                        
                                    } catch(Exception e){
                                        e.printStackTrace();
                                    }
                                }else{
                                    try{
                                        JOptionPane.showMessageDialog(null, "Se han guardados nuevos datos ");
                                        archivosDatos.createNewFile();
                                        escribir = new FileWriter(archivosDatos,true);
                                        insertarLinea = new PrintWriter(escribir);
                                        insertarLinea.print("Los puntos de "+jugadorX+ " son "+puntos+"\n");
                                        insertarLinea.print("Fecha en la que se jugo: "+fecha()+"\n");
                                        insertarLinea.print("-------------------------------------------------"+"\n");
                                        escribir.close();
                                        System.exit(0);
                                        
                                    } catch(Exception e){
                                        e.printStackTrace();
                                    }
                                }
                } else if(cabeza.getLocation().getY()>=780){
                    JOptionPane.showMessageDialog(null, "Fin has colisionado tus puntos son: "+puntos);
                    if(!archivosDatos.exists()){
                                    try{
                                        JOptionPane.showMessageDialog(null, "Se han guardado tus datos ");
                                        archivosDatos.createNewFile();
                                        escribir = new FileWriter(archivosDatos,true);
                                        insertarLinea = new PrintWriter(escribir);
                                        insertarLinea.print("Los puntos de "+jugadorX+ " son "+puntos+"\n");
                                        insertarLinea.print("Fecha en la que se jugo: "+fecha()+"\n");
                                        insertarLinea.print("-------------------------------------------------"+"\n");
                                        escribir.close();
                                        System.exit(0);
                                        
                                    } catch(Exception e){
                                        e.printStackTrace();
                                    }
                                }else{
                                    try{
                                        JOptionPane.showMessageDialog(null, "Se han guardados nuevos datos ");
                                        archivosDatos.createNewFile();
                                        escribir = new FileWriter(archivosDatos,true);
                                        insertarLinea = new PrintWriter(escribir);
                                        insertarLinea.print("Los puntos de "+jugadorX+ " son "+puntos+"\n");
                                        insertarLinea.print("Fecha en la que se jugo: "+fecha()+"\n");
                                        insertarLinea.print("-------------------------------------------------"+"\n");
                                        escribir.close();
                                        System.exit(0);
                                        
                                    } catch(Exception e){
                                        e.printStackTrace();
                                    }
                                }
                } else if(cabeza.getLocation().getX()<0){     
                    JOptionPane.showMessageDialog(null, "Fin has colisionado tus puntos son: "+puntos);
                    if(!archivosDatos.exists()){
                                    try{
                                        JOptionPane.showMessageDialog(null, "Se han guardado tus datos ");
                                        archivosDatos.createNewFile();
                                        escribir = new FileWriter(archivosDatos,true);
                                        insertarLinea = new PrintWriter(escribir);
                                        insertarLinea.print("Los puntos de "+jugadorX+ " son "+puntos+"\n");
                                        insertarLinea.print("Fecha en la que se jugo: "+fecha()+"\n");
                                        insertarLinea.print("-------------------------------------------------"+"\n");
                                        escribir.close();
                                        System.exit(0);
                                        
                                    } catch(Exception e){
                                        e.printStackTrace();
                                    }
                                }else{
                                    try{
                                        JOptionPane.showMessageDialog(null, "Se han guardados nuevos datos ");
                                        archivosDatos.createNewFile();
                                        escribir = new FileWriter(archivosDatos,true);
                                        insertarLinea = new PrintWriter(escribir);
                                        insertarLinea.print("Los puntos de "+jugadorX+ " son "+puntos+"\n");
                                        insertarLinea.print("Fecha en la que se jugo: "+fecha()+"\n");
                                        insertarLinea.print("-------------------------------------------------"+"\n");
                                        escribir.close();
                                        System.exit(0);
                                        
                                    } catch(Exception e){
                                        e.printStackTrace();
                                    }
                                }
                } else if(cabeza.getLocation().getY()<0){
                    JOptionPane.showMessageDialog(null, "Fin has colisonado tus puntos son: "+puntos);
                    if(!archivosDatos.exists()){
                                    try{
                                        JOptionPane.showMessageDialog(null, "Se han guardado tus datos ");
                                        archivosDatos.createNewFile();
                                        escribir = new FileWriter(archivosDatos,true);
                                        insertarLinea = new PrintWriter(escribir);
                                        insertarLinea.print("Los puntos de "+jugadorX+ " son "+puntos+"\n");
                                        insertarLinea.print("Fecha en la que se jugo: "+fecha()+"\n");
                                        insertarLinea.print("-------------------------------------------------"+"\n");
                                        escribir.close();
                                        System.exit(0);
                                        
                                    } catch(Exception e){
                                        e.printStackTrace();
                                    }
                                }else{
                                    try{
                                        JOptionPane.showMessageDialog(null, "Se han guardados nuevos datos ");
                                        archivosDatos.createNewFile();
                                        escribir = new FileWriter(archivosDatos,true);
                                        insertarLinea = new PrintWriter(escribir);
                                        insertarLinea.print("Los puntos de "+jugadorX+ " son "+puntos+"\n");
                                        insertarLinea.print("Fecha en la que se jugo: "+fecha()+"\n");
                                        insertarLinea.print("-------------------------------------------------"+"\n");
                                        escribir.close();
                                        System.exit(0);
                                        
                                    } catch(Exception e){
                                        e.printStackTrace();
                                    }
                                }
                } else if(puntos == 10){
                    JOptionPane.showMessageDialog(null, "Ganaste, tus puntos maximos son: "+puntos);
                    if(!archivosDatos.exists()){
                                    try{
                                        JOptionPane.showMessageDialog(null, "Se han guardado tus datos de tu excelente puntuacion");
                                        archivosDatos.createNewFile();
                                        escribir = new FileWriter(archivosDatos,true);
                                        insertarLinea = new PrintWriter(escribir);
                                        insertarLinea.print("Felicidades "+jugadorX+ " alcanzaste los puntos maximos "+puntos+"\n");
                                        insertarLinea.print("Fecha en la que se jugo: "+fecha()+"\n");
                                        insertarLinea.print("-------------------------------------------------"+"\n");
                                        escribir.close();
                                        System.exit(0);
                                        
                                    } catch(Exception e){
                                        e.printStackTrace();
                                    }
                                }else{
                                    try{
                                        JOptionPane.showMessageDialog(null, "Se han guardados nuevos datos de tu excelente puntuacion");
                                        archivosDatos.createNewFile();
                                        escribir = new FileWriter(archivosDatos,true);
                                        insertarLinea = new PrintWriter(escribir);
                                        insertarLinea.print("Felicidades "+jugadorX+ " Alcanzaste los puntos maximos "+puntos+"\n");
                                        insertarLinea.print("Fecha en la que se jugo: "+fecha()+"\n");
                                        insertarLinea.print("-------------------------------------------------"+"\n");
                                        escribir.close();
                                        System.exit(0);
                                        
                                    } catch(Exception e){
                                        e.printStackTrace();
                                    }
                                }
                }
  
            }
        };
        p.schedule(movimiento, 0,100);
    }
    public void nombreJugador(){
        jugadorX = JOptionPane.showInputDialog("Digite su nombre: ");
        jLabel2.setText("Jugador: "+jugadorX);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        lbFecha = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(102, 255, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 51), 5));
        jPanel1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jPanel1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 490, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 790, Short.MAX_VALUE)
        );

        jLabel2.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N

        jPanel2.setBackground(new java.awt.Color(102, 153, 0));

        jLabel1.setFont(new java.awt.Font("Arial Black", 0, 24)); // NOI18N
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 51), 7));

        jLabel3.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel3.setText("Fecha:");

        lbFecha.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        lbFecha.setText("DD/MM/YYYY");

        jLabel4.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Suerte");

        jLabel5.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Juego Snake.");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(172, 172, 172))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(130, 130, 130)
                        .addComponent(jLabel5))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 448, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(lbFecha)))
                .addContainerGap(62, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel5)
                .addGap(26, 26, 26)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(lbFecha))
                .addGap(195, 195, 195)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(204, 204, 204))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jPanel1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jPanel1KeyPressed
       
    }//GEN-LAST:event_jPanel1KeyPressed
    public static String fecha(){
        Date fecha = new Date();
        SimpleDateFormat formatofecha=new SimpleDateFormat("dd/MM/YYYY");
        return formatofecha.format(fecha);
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Snake.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Snake.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Snake.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Snake.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Snake().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lbFecha;
    // End of variables declaration//GEN-END:variables

    @Override
    public void keyTyped(KeyEvent e) {
        
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if(e.getKeyCode()==KeyEvent.VK_UP){
            if(direccion!=3)
                direccion=4;
        }else if(e.getKeyCode()==KeyEvent.VK_DOWN){
            if(direccion!=4)
                direccion=3;
        }else if(e.getKeyCode()==KeyEvent.VK_LEFT){
            if(direccion!=1)
                direccion=2;
        }else if(e.getKeyCode()==KeyEvent.VK_RIGHT){
            if(direccion!=2)
                direccion=1;
        }
        //Here is the option which allows, through the keyevent, to move the snake with the keyboard arrows
    }

    @Override
    public void keyReleased(KeyEvent e) {
        
    }
}
