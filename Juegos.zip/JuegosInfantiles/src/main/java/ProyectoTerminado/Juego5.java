/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProyectoTerminado;

import ProyectoTerminado.Ganador;
import ProyectoTerminado.Empate;
import static ProyectoTerminado.Jugadores.Jugador;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;

public class Juego5 extends javax.swing.JDialog {
    int turno =1;
    int puntos,puntos2;
    boolean pase=true;
    Jugadores global= new Jugadores();
    public Juego5(javax.swing.JDialog parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setLocationRelativeTo(null);
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss");
        String h=dtf.format(LocalDateTime.now());
        txtHora.setText(h);
        
        DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        String f=dtf1.format(LocalDateTime.now());
        txtFecha.setText(f);
        
    }
    public void ganador(){
        //Columnas
        
        verificacion(bnt1, bnt2, bnt3,bnt4,bnt5);
        verificacion(bnt6, bnt7, bnt8,bnt9,bnt10);
        verificacion(bnt11, bnt12, bnt13,bnt14,bnt15);
        verificacion(bnt16, bnt17, bnt18,bnt19,bnt20);
        verificacion(bnt21, bnt22, bnt23,bnt24,bnt25);
        
        //Filas
        verificacion(bnt1, bnt6, bnt11,bnt16,bnt21);
        verificacion(bnt2, bnt7, bnt12,bnt17,bnt22);
        verificacion(bnt3, bnt8, bnt13,bnt18,bnt23);
        verificacion(bnt4, bnt9, bnt14,bnt19,bnt20);
        verificacion(bnt5, bnt10, bnt15,bnt20,bnt25);
        
        //Diagonal principal
        verificacion(bnt1, bnt7, bnt13,bnt19,bnt25);
        
        //Diagonal secundaria
        verificacion(bnt5, bnt9, bnt13,bnt17,bnt21);
        
    }
    public void verificacion(JButton A1,JButton A2,JButton A3,JButton A4,JButton A5){
        String condi_1=A1.getText();
        String condi_2=A2.getText();
        String condi_3=A3.getText();
        String condi_4=A4.getText();
        String condi_5=A5.getText();
        if (condi_1=="x"&&condi_2=="x"&&condi_3=="x"&&condi_4=="x"&&condi_5=="x") {
         pase=false;
         A1.setIcon(new ImageIcon("ganador.jpg"));
         A2.setIcon(new ImageIcon("ganador.jpg"));
         A3.setIcon(new ImageIcon("ganador.jpg"));
         A4.setIcon(new ImageIcon("ganador.jpg"));
         A5.setIcon(new ImageIcon("ganador.jpg"));
         
         puntos=Integer.parseInt(txtP1.getText());
         puntos=puntos*2;
         txtP2.setText(Integer.toString(puntos));
         
         String nombre=Jugador.get(0).getNombre();
         String puntos=Jugador.get(0).getPuntos();
         global.agregaGanador(nombre,puntos);
         Ganador ventanaGanador= new Ganador(new javax.swing.JDialog(),true);         
         ventanaGanador.setVisible(true);
         
         
       
        }else if(condi_1=="O"&&condi_2=="O"&&condi_3=="O"&&condi_4=="O"&&condi_5=="O"){
         pase=false;
         A1.setIcon(new ImageIcon("ganador.jpg"));
         A2.setIcon(new ImageIcon("ganador.jpg"));
         A3.setIcon(new ImageIcon("ganador.jpg"));
         A4.setIcon(new ImageIcon("ganador.jpg"));
         A5.setIcon(new ImageIcon("ganador.jpg"));
         puntos2=Integer.parseInt(txtP2.getText());
         puntos2=puntos2*2;
         txtP2.setText(Integer.toString(puntos2));
        
         String nombre=Jugador.get(0).getNombre();
         String puntos=Jugador.get(0).getPuntos();
         global.agregaGanador(nombre,puntos);                 
         Ganador ventanaGanador= new Ganador(new javax.swing.JDialog(),true);         
         ventanaGanador.setVisible(true);
         
         
        }
        
    }
    
    public void turno(JButton A1){
        String condi=A1.getText();
        if(condi==""){
            if (turno==1) {
                A1.setText("x");
                A1.setIcon(new ImageIcon("Jugador1.jpg"));
                puntos=Integer.parseInt(txtP1.getText());
                puntos=puntos+1; 
                txtP1.setText(Integer.toString(puntos));
                turno=2;
                
            }else if(turno==2){
                A1.setText("O");
                A1.setIcon(new ImageIcon("Jugador2.jpg"));
                turno=1;
                puntos2=Integer.parseInt(txtP2.getText());
                puntos2=puntos2+1; 
                txtP2.setText(Integer.toString(puntos2));
            }
        }
    }
    public void Empata(){
        if (pase==true) {
            JButton []arrBtn = new JButton[25];
        arrBtn[0]=bnt1;arrBtn[1]=bnt2;arrBtn[2]=bnt3;arrBtn[3]=bnt4;
        arrBtn[4]=bnt5;arrBtn[5]=bnt6;arrBtn[6]=bnt7;arrBtn[7]=bnt8;
        arrBtn[8]=bnt9;arrBtn[9]=bnt10;arrBtn[10]=bnt11;arrBtn[11]=bnt12;
        arrBtn[12]=bnt13;arrBtn[13]=bnt14;arrBtn[14]=bnt15;arrBtn[15]=bnt16;
        arrBtn[16]=bnt17;arrBtn[17]=bnt18;arrBtn[18]=bnt19;arrBtn[19]=bnt20;
        arrBtn[20]=bnt21;arrBtn[21]=bnt22;arrBtn[22]=bnt23;arrBtn[23]=bnt24;
        arrBtn[24]=bnt25;
        
        String condi;
        String []valores=new String[arrBtn.length];
        int contador=0;
        int contador2=0;
        for (int i =0; i < arrBtn.length; i++) {
           condi=arrBtn[i].getText();
           valores[i]=condi;
        }
        for (int j = 0; j <valores.length; j++) {                
           if (valores[j]=="x") {
              contador+=1;  
               if (contador>=13) {
                    Empate  ventanaEmpatados= new Empate(new javax.swing.JDialog(),true);         
                    ventanaEmpatados.setVisible(true);
         
               }
            }else if(valores[j]=="O"){
              contador2+=1;
              if (contador2>=13) {
                    Empate  ventanaEmpatados= new Empate(new javax.swing.JDialog(),true);         
                    ventanaEmpatados.setVisible(true);
         
               }
            }
              
        }
            
        }
        
     
    }
    public void reiniciar(){
        pase=true;
        JOptionPane.showMessageDialog(rootPane,"El Juego se esta reiniciando......");
        JOptionPane.showMessageDialog(rootPane,"Comienza Jugador que perdio");
        puntos=0;puntos2=0;        
        txtP1.setText(Integer.toString(puntos));
        txtP2.setText(Integer.toString(puntos));
        
        JButton []arrBtn = new JButton[25];
        arrBtn[0]=bnt1;arrBtn[1]=bnt2;arrBtn[2]=bnt3;arrBtn[3]=bnt4;
        arrBtn[4]=bnt5;arrBtn[5]=bnt6;arrBtn[6]=bnt7;arrBtn[7]=bnt8;
        arrBtn[8]=bnt9;arrBtn[9]=bnt10;arrBtn[10]=bnt11;arrBtn[11]=bnt12;
        arrBtn[12]=bnt13;arrBtn[13]=bnt14;arrBtn[14]=bnt15;arrBtn[15]=bnt16;
        arrBtn[16]=bnt17;arrBtn[17]=bnt18;arrBtn[18]=bnt19;arrBtn[19]=bnt20;
        arrBtn[20]=bnt21;arrBtn[21]=bnt22;arrBtn[22]=bnt23;arrBtn[23]=bnt24;
        arrBtn[24]=bnt25;
        
        for (int i =0; i < arrBtn.length; i++) {
           arrBtn[i].setText("");
           arrBtn[i].setIcon(null);
        }
    }
    public  void datos(){   
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss");
        String h=dtf.format(LocalDateTime.now());
        txtHora.setText(h);
        
        DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        String f=dtf1.format(LocalDateTime.now());
        txtFecha.setText(f);
        
        lblNom1.setText(Jugador.get(0).getNombre());
        lblNom2.setText(Jugador.get(1).getNombre());
        
    
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        bnt6 = new javax.swing.JButton();
        bnt1 = new javax.swing.JButton();
        bnt8 = new javax.swing.JButton();
        bnt3 = new javax.swing.JButton();
        bnt2 = new javax.swing.JButton();
        bnt7 = new javax.swing.JButton();
        bnt13 = new javax.swing.JButton();
        bnt11 = new javax.swing.JButton();
        bnt12 = new javax.swing.JButton();
        lblNom1 = new javax.swing.JLabel();
        lblNom2 = new javax.swing.JLabel();
        txtP2 = new javax.swing.JTextField();
        txtP1 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        lblFecha = new javax.swing.JLabel();
        btnReiniciar = new javax.swing.JButton();
        Volver = new javax.swing.JButton();
        txtFecha = new javax.swing.JTextField();
        txtHora = new javax.swing.JTextField();
        bnt18 = new javax.swing.JButton();
        bnt5 = new javax.swing.JButton();
        bnt4 = new javax.swing.JButton();
        bnt9 = new javax.swing.JButton();
        bnt19 = new javax.swing.JButton();
        bnt10 = new javax.swing.JButton();
        bnt16 = new javax.swing.JButton();
        bnt17 = new javax.swing.JButton();
        bnt14 = new javax.swing.JButton();
        bnt22 = new javax.swing.JButton();
        bnt21 = new javax.swing.JButton();
        bnt23 = new javax.swing.JButton();
        bnt24 = new javax.swing.JButton();
        bnt25 = new javax.swing.JButton();
        bnt15 = new javax.swing.JButton();
        bnt20 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.red, java.awt.Color.red, java.awt.Color.red, java.awt.Color.red));

        bnt6.setBackground(new java.awt.Color(0, 0, 0));
        bnt6.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt6ActionPerformed(evt);
            }
        });

        bnt1.setBackground(new java.awt.Color(0, 0, 0));
        bnt1.setForeground(new java.awt.Color(255, 0, 51));
        bnt1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt1ActionPerformed(evt);
            }
        });

        bnt8.setBackground(new java.awt.Color(0, 0, 0));
        bnt8.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt8ActionPerformed(evt);
            }
        });

        bnt3.setBackground(new java.awt.Color(0, 0, 0));
        bnt3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt3ActionPerformed(evt);
            }
        });

        bnt2.setBackground(new java.awt.Color(0, 0, 0));
        bnt2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt2ActionPerformed(evt);
            }
        });

        bnt7.setBackground(new java.awt.Color(0, 0, 0));
        bnt7.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt7ActionPerformed(evt);
            }
        });

        bnt13.setBackground(new java.awt.Color(0, 0, 0));
        bnt13.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt13ActionPerformed(evt);
            }
        });

        bnt11.setBackground(new java.awt.Color(0, 0, 0));
        bnt11.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt11ActionPerformed(evt);
            }
        });

        bnt12.setBackground(new java.awt.Color(0, 0, 0));
        bnt12.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt12ActionPerformed(evt);
            }
        });

        lblNom1.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        lblNom1.setForeground(new java.awt.Color(255, 255, 255));
        lblNom1.setText("Jugador1");
        lblNom1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));

        lblNom2.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        lblNom2.setForeground(new java.awt.Color(255, 255, 255));
        lblNom2.setText("Jugador2");
        lblNom2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));

        txtP2.setEditable(false);
        txtP2.setBackground(new java.awt.Color(0, 0, 0));
        txtP2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        txtP2.setForeground(new java.awt.Color(255, 255, 255));
        txtP2.setText("0");
        txtP2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));

        txtP1.setEditable(false);
        txtP1.setBackground(new java.awt.Color(0, 0, 0));
        txtP1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        txtP1.setForeground(new java.awt.Color(255, 255, 255));
        txtP1.setText("0");
        txtP1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));

        jLabel3.setBackground(new java.awt.Color(0, 0, 0));
        jLabel3.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Hora:");
        jLabel3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));

        lblFecha.setBackground(new java.awt.Color(0, 0, 0));
        lblFecha.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        lblFecha.setForeground(new java.awt.Color(255, 255, 255));
        lblFecha.setText("Fecha:");
        lblFecha.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));

        btnReiniciar.setBackground(new java.awt.Color(0, 0, 0));
        btnReiniciar.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        btnReiniciar.setForeground(new java.awt.Color(255, 255, 255));
        btnReiniciar.setText("Reiniciar");
        btnReiniciar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        btnReiniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReiniciarActionPerformed(evt);
            }
        });

        Volver.setBackground(new java.awt.Color(0, 0, 0));
        Volver.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        Volver.setForeground(new java.awt.Color(255, 255, 255));
        Volver.setText("Volver al menú");
        Volver.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        Volver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VolverActionPerformed(evt);
            }
        });

        txtFecha.setEditable(false);
        txtFecha.setBackground(new java.awt.Color(0, 0, 0));
        txtFecha.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        txtFecha.setForeground(new java.awt.Color(255, 255, 255));
        txtFecha.setText("0");
        txtFecha.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));

        txtHora.setEditable(false);
        txtHora.setBackground(new java.awt.Color(0, 0, 0));
        txtHora.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        txtHora.setForeground(new java.awt.Color(255, 255, 255));
        txtHora.setText("0");
        txtHora.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));

        bnt18.setBackground(new java.awt.Color(0, 0, 0));
        bnt18.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt18ActionPerformed(evt);
            }
        });

        bnt5.setBackground(new java.awt.Color(0, 0, 0));
        bnt5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt5ActionPerformed(evt);
            }
        });

        bnt4.setBackground(new java.awt.Color(0, 0, 0));
        bnt4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt4ActionPerformed(evt);
            }
        });

        bnt9.setBackground(new java.awt.Color(0, 0, 0));
        bnt9.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt9ActionPerformed(evt);
            }
        });

        bnt19.setBackground(new java.awt.Color(0, 0, 0));
        bnt19.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt19ActionPerformed(evt);
            }
        });

        bnt10.setBackground(new java.awt.Color(0, 0, 0));
        bnt10.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt10ActionPerformed(evt);
            }
        });

        bnt16.setBackground(new java.awt.Color(0, 0, 0));
        bnt16.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt16ActionPerformed(evt);
            }
        });

        bnt17.setBackground(new java.awt.Color(0, 0, 0));
        bnt17.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt17ActionPerformed(evt);
            }
        });

        bnt14.setBackground(new java.awt.Color(0, 0, 0));
        bnt14.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt14ActionPerformed(evt);
            }
        });

        bnt22.setBackground(new java.awt.Color(0, 0, 0));
        bnt22.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt22ActionPerformed(evt);
            }
        });

        bnt21.setBackground(new java.awt.Color(0, 0, 0));
        bnt21.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt21ActionPerformed(evt);
            }
        });

        bnt23.setBackground(new java.awt.Color(0, 0, 0));
        bnt23.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt23ActionPerformed(evt);
            }
        });

        bnt24.setBackground(new java.awt.Color(0, 0, 0));
        bnt24.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt24ActionPerformed(evt);
            }
        });

        bnt25.setBackground(new java.awt.Color(0, 0, 0));
        bnt25.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt25ActionPerformed(evt);
            }
        });

        bnt15.setBackground(new java.awt.Color(0, 0, 0));
        bnt15.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt15ActionPerformed(evt);
            }
        });

        bnt20.setBackground(new java.awt.Color(0, 0, 0));
        bnt20.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt20ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblFecha, javax.swing.GroupLayout.DEFAULT_SIZE, 45, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(bnt11, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(bnt16, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(bnt21, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(bnt12, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt13, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt14, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt15, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(bnt17, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt18, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt19, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt20, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(bnt22, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt23, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt24, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt25, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(bnt6, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(bnt1, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(bnt2, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(bnt7, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(bnt8, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(bnt3, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(bnt4, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt5, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt9, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt10, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addContainerGap(181, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtHora, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnReiniciar, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblNom1, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblNom2, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtP2, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                                    .addComponent(txtP1))))
                        .addGap(32, 32, 32))))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(48, 48, 48)
                    .addComponent(Volver, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(548, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblNom1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(txtP1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtP2, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblNom2, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtHora, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bnt2, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bnt1, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bnt3, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bnt4, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bnt5, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(bnt7, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bnt6, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bnt8, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bnt9, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(bnt12, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(bnt13, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(bnt14, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(bnt15, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addComponent(btnReiniciar))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(bnt18, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(bnt17, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(bnt19, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(bnt16, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(bnt20, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(bnt21, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(bnt22, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(bnt23, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(bnt24, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(bnt25, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(0, 78, Short.MAX_VALUE))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(bnt11, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(bnt10, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                    .addContainerGap(604, Short.MAX_VALUE)
                    .addComponent(Volver)
                    .addGap(1, 1, 1)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bnt1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt1ActionPerformed
        turno(bnt1);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt1ActionPerformed

    private void bnt3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt3ActionPerformed
       turno(bnt3);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt3ActionPerformed

    private void btnReiniciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReiniciarActionPerformed
        reiniciar();
    }//GEN-LAST:event_btnReiniciarActionPerformed

    private void VolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VolverActionPerformed
        this.dispose();
    }//GEN-LAST:event_VolverActionPerformed

    private void bnt18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt18ActionPerformed
        turno(bnt18);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt18ActionPerformed

    private void bnt5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt5ActionPerformed
        turno(bnt5);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt5ActionPerformed

    private void bnt4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt4ActionPerformed
        turno(bnt4);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt4ActionPerformed

    private void bnt9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt9ActionPerformed
        turno(bnt9);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt9ActionPerformed

    private void bnt19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt19ActionPerformed
        turno(bnt19);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt19ActionPerformed

    private void bnt10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt10ActionPerformed
        turno(bnt10);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt10ActionPerformed

    private void bnt16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt16ActionPerformed
        turno(bnt16);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt16ActionPerformed

    private void bnt17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt17ActionPerformed
        turno(bnt17);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt17ActionPerformed

    private void bnt14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt14ActionPerformed
        turno(bnt14);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt14ActionPerformed

    private void bnt22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt22ActionPerformed
        turno(bnt22);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt22ActionPerformed

    private void bnt21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt21ActionPerformed
       turno(bnt21);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt21ActionPerformed

    private void bnt23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt23ActionPerformed
        turno(bnt23);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt23ActionPerformed

    private void bnt24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt24ActionPerformed
        turno(bnt24);
        ganador();
        Empata();
        
    }//GEN-LAST:event_bnt24ActionPerformed

    private void bnt25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt25ActionPerformed
        turno(bnt25);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt25ActionPerformed

    private void bnt15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt15ActionPerformed
        turno(bnt15);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt15ActionPerformed

    private void bnt20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt20ActionPerformed
        turno(bnt20);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt20ActionPerformed

    private void bnt2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt2ActionPerformed
        turno(bnt2);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt2ActionPerformed

    private void bnt6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt6ActionPerformed
        turno(bnt6);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt6ActionPerformed

    private void bnt7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt7ActionPerformed
        turno(bnt7);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt7ActionPerformed

    private void bnt8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt8ActionPerformed
        turno(bnt8);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt8ActionPerformed

    private void bnt11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt11ActionPerformed
        turno(bnt11);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt11ActionPerformed

    private void bnt12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt12ActionPerformed
        turno(bnt12);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt12ActionPerformed

    private void bnt13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt13ActionPerformed
        turno(bnt13);
        ganador();
        Empata();
    }//GEN-LAST:event_bnt13ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Juego5.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Juego5.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Juego5.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Juego5.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Juego5 dialog = new Juego5(new javax.swing.JDialog(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Volver;
    private javax.swing.JButton bnt1;
    private javax.swing.JButton bnt10;
    private javax.swing.JButton bnt11;
    private javax.swing.JButton bnt12;
    private javax.swing.JButton bnt13;
    private javax.swing.JButton bnt14;
    private javax.swing.JButton bnt15;
    private javax.swing.JButton bnt16;
    private javax.swing.JButton bnt17;
    private javax.swing.JButton bnt18;
    private javax.swing.JButton bnt19;
    private javax.swing.JButton bnt2;
    private javax.swing.JButton bnt20;
    private javax.swing.JButton bnt21;
    private javax.swing.JButton bnt22;
    private javax.swing.JButton bnt23;
    private javax.swing.JButton bnt24;
    private javax.swing.JButton bnt25;
    private javax.swing.JButton bnt3;
    private javax.swing.JButton bnt4;
    private javax.swing.JButton bnt5;
    private javax.swing.JButton bnt6;
    private javax.swing.JButton bnt7;
    private javax.swing.JButton bnt8;
    private javax.swing.JButton bnt9;
    private javax.swing.JButton btnReiniciar;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblFecha;
    private javax.swing.JLabel lblNom1;
    private javax.swing.JLabel lblNom2;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtHora;
    private javax.swing.JTextField txtP1;
    private javax.swing.JTextField txtP2;
    // End of variables declaration//GEN-END:variables
}
