/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProyectoTerminado;

import ProyectoTerminado.Ganador;
import ProyectoTerminado.Empate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;

/**
 *
 * @author huawei
 */
public class Juego7 extends javax.swing.JDialog {
    int turno =1;
    int puntos,puntos2;
    boolean pase=true;
    public Juego7(javax.swing.JDialog parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setLocationRelativeTo(null);
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss");
        String h=dtf.format(LocalDateTime.now());
        txtHora.setText(h);
        
        DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        String f=dtf1.format(LocalDateTime.now());
        txtFecha.setText(f);
        
    }
   public void ganador(){
        //Columnas
        
        verificacion(bnt1, bnt2, bnt3,bnt4,bnt5,bnt6,bnt7);
        verificacion( bnt8,bnt9,bnt10,bnt11,bnt12,bnt13,bnt14);
        verificacion(bnt15,bnt16, bnt17, bnt18,bnt19,bnt20, bnt21);
        verificacion(bnt22,bnt23, bnt24, bnt25,bnt26,bnt27, bnt28);
        verificacion(bnt29,bnt30, bnt31, bnt32,bnt33,bnt34, bnt35);
        verificacion(bnt36,bnt37, bnt38, bnt39,bnt40,bnt41, bnt42);
        verificacion(bnt43,bnt44, bnt45, bnt46,bnt47,bnt48, bnt49);
        
        //Filas
     
        
        verificacion(bnt1, bnt8, bnt15,bnt22,bnt29,bnt36,bnt43);
        verificacion( bnt2,bnt9,bnt16,bnt23,bnt30,bnt37,bnt44);
        verificacion(bnt3,bnt10, bnt17, bnt24,bnt31,bnt38, bnt45);
        verificacion(bnt4,bnt11, bnt18, bnt25,bnt32,bnt39, bnt46);
        verificacion(bnt5,bnt12, bnt19, bnt26,bnt34,bnt40, bnt47);
        verificacion(bnt6,bnt33, bnt20, bnt27,bnt35,bnt41, bnt48);
        verificacion(bnt7,bnt14, bnt21, bnt28,bnt36,bnt42, bnt49);
        //Diagonal principal
        verificacion(bnt1, bnt9, bnt17,bnt25,bnt33,bnt41,bnt49);
        
        //Diagonal secundaria
        verificacion(bnt7, bnt13, bnt19,bnt25,bnt31,bnt37,bnt43);
        
    }
    public void verificacion(JButton A1,JButton A2,JButton A3,JButton A4,JButton A5,JButton A6,JButton A7){
        String condi_1=A1.getText();
        String condi_2=A2.getText();
        String condi_3=A3.getText();
        String condi_4=A4.getText();
        String condi_5=A5.getText();
        String condi_6=A6.getText();
        String condi_7=A7.getText();
        if (condi_1=="x"&&condi_2=="x"&&condi_3=="x"&&condi_4=="x"&&condi_5=="x"&&condi_6=="x"&&condi_7=="x") {
         pase=false;
         A1.setIcon(new ImageIcon("ganador.jpg"));
         A2.setIcon(new ImageIcon("ganador.jpg"));
         A3.setIcon(new ImageIcon("ganador.jpg"));
         A4.setIcon(new ImageIcon("ganador.jpg"));
         A5.setIcon(new ImageIcon("ganador.jpg"));         
         A6.setIcon(new ImageIcon("ganador.jpg"));
         A7.setIcon(new ImageIcon("ganador.jpg"));
         puntos=Integer.parseInt(txtP2.getText());
         puntos=puntos*2;
         txtP2.setText(Integer.toString(puntos));
         Ganador ventanaGanador= new Ganador(new javax.swing.JDialog(),true);         
         ventanaGanador.setVisible(true);
         this.dispose();
         
       
        }else if(condi_1=="O"&&condi_2=="O"&&condi_3=="O"&&condi_4=="O"&&condi_5=="O"&&condi_6=="O"&&condi_7=="O"){
         pase=false;   
         A1.setIcon(new ImageIcon("ganador.jpg"));
         A2.setIcon(new ImageIcon("ganador.jpg"));
         A3.setIcon(new ImageIcon("ganador.jpg"));
         A4.setIcon(new ImageIcon("ganador.jpg"));
         A5.setIcon(new ImageIcon("ganador.jpg"));
         A6.setIcon(new ImageIcon("ganador.jpg"));
         A7.setIcon(new ImageIcon("ganador.jpg"));
         puntos2=Integer.parseInt(txtP2.getText());
         puntos2=puntos2*2;
         txtP2.setText(Integer.toString(puntos2));
         Ganador ventanaGanador= new Ganador(new javax.swing.JDialog(),true);         
         ventanaGanador.setVisible(true);
         this.dispose();
         
        }
        
    }
    
    public void turno(JButton A1){
        String condi=A1.getText();
        if(condi==""){
            if (turno==1) {
                A1.setText("x");
                A1.setIcon(new ImageIcon("Jugador1.jpg"));
                puntos=Integer.parseInt(txtP1.getText());
                puntos=puntos+1; 
                txtP1.setText(Integer.toString(puntos));
                turno=2;
                
            }else if(turno==2){
                A1.setText("O");
                A1.setIcon(new ImageIcon("Jugador2.jpg"));
                turno=1;
                puntos2=Integer.parseInt(txtP2.getText());
                puntos2=puntos2+1; 
                txtP2.setText(Integer.toString(puntos2));
            }
        }
    }
    public void Empata(){
        if (pase==true) {
            
        JButton []arrBtn = new JButton[49];
         arrBtn[0]=bnt1;arrBtn[1]=bnt2;arrBtn[2]=bnt3;arrBtn[3]=bnt4;
        arrBtn[4]=bnt5;arrBtn[5]=bnt6;arrBtn[6]=bnt7;arrBtn[7]=bnt8;
        arrBtn[8]=bnt9;arrBtn[9]=bnt10;arrBtn[10]=bnt11;arrBtn[11]=bnt12;
        arrBtn[12]=bnt13;arrBtn[13]=bnt14;arrBtn[14]=bnt15;arrBtn[15]=bnt16;
        arrBtn[16]=bnt17;arrBtn[17]=bnt18;arrBtn[18]=bnt19;arrBtn[19]=bnt20;
        arrBtn[20]=bnt21;arrBtn[21]=bnt22;arrBtn[22]=bnt23;arrBtn[23]=bnt24;
        arrBtn[24]=bnt25;arrBtn[25]=bnt26;arrBtn[26]=bnt27;arrBtn[27]=bnt28;
        arrBtn[28]=bnt29;arrBtn[29]=bnt30;arrBtn[30]=bnt31;arrBtn[31]=bnt32;
        arrBtn[32]=bnt33;arrBtn[33]=bnt34;arrBtn[34]=bnt35;arrBtn[35]=bnt36;
        arrBtn[36]=bnt37;arrBtn[37]=bnt38;arrBtn[38]=bnt39;arrBtn[39]=bnt40;
        arrBtn[40]=bnt41;arrBtn[41]=bnt42;arrBtn[42]=bnt43;arrBtn[43]=bnt44;
        arrBtn[44]=bnt45;arrBtn[45]=bnt46;arrBtn[46]=bnt47;arrBtn[47]=bnt48;
        arrBtn[48]=bnt49;
        
        String condi;
        String []valores=new String[arrBtn.length];
        int contador=0;
        int contador2=0;
        for (int i =0; i < arrBtn.length; i++) {
           condi=arrBtn[i].getText();
           valores[i]=condi;
        }
        for (int j = 0; j <valores.length; j++) {                
           if (valores[j]=="x") {
              contador+=1;  
               if (contador>=25) {
                    Empate  ventanaEmpatados= new Empate(new javax.swing.JDialog(),true);         
                    ventanaEmpatados.setVisible(true);
         
               }
            }else if(valores[j]=="O"){
              contador2+=1;
              if (contador2>=25) {
                   Empate  ventanaEmpatados= new Empate(new javax.swing.JDialog(),true);         
                    ventanaEmpatados.setVisible(true);
         
               }
            }
              
        }
            
        }
        
     
    }
    public void reiniciar(){
        pase=true;
        JOptionPane.showMessageDialog(rootPane,"El Juego se esta reiniciando......");
        JOptionPane.showMessageDialog(rootPane,"Comienza El Jugador que PERDIÓ");
        puntos=0;puntos2=0;        
        txtP1.setText(Integer.toString(puntos));
        txtP2.setText(Integer.toString(puntos));
        
        JButton []arrBtn = new JButton[49];
        arrBtn[0]=bnt1;arrBtn[1]=bnt2;arrBtn[2]=bnt3;arrBtn[3]=bnt4;
        arrBtn[4]=bnt5;arrBtn[5]=bnt6;arrBtn[6]=bnt7;arrBtn[7]=bnt8;
        arrBtn[8]=bnt9;arrBtn[9]=bnt10;arrBtn[10]=bnt11;arrBtn[11]=bnt12;
        arrBtn[12]=bnt13;arrBtn[13]=bnt14;arrBtn[14]=bnt15;arrBtn[15]=bnt16;
        arrBtn[16]=bnt17;arrBtn[17]=bnt18;arrBtn[18]=bnt19;arrBtn[19]=bnt20;
        arrBtn[20]=bnt21;arrBtn[21]=bnt22;arrBtn[22]=bnt23;arrBtn[23]=bnt24;
        arrBtn[24]=bnt25;arrBtn[25]=bnt26;arrBtn[26]=bnt27;arrBtn[27]=bnt28;
        arrBtn[28]=bnt29;arrBtn[29]=bnt30;arrBtn[30]=bnt31;arrBtn[31]=bnt32;
        arrBtn[32]=bnt33;arrBtn[33]=bnt34;arrBtn[34]=bnt35;arrBtn[35]=bnt36;
        arrBtn[36]=bnt37;arrBtn[37]=bnt38;arrBtn[38]=bnt39;arrBtn[39]=bnt40;
        arrBtn[40]=bnt41;arrBtn[41]=bnt42;arrBtn[42]=bnt43;arrBtn[43]=bnt44;
        arrBtn[44]=bnt45;arrBtn[45]=bnt46;arrBtn[46]=bnt47;arrBtn[47]=bnt48;
        arrBtn[48]=bnt49;
        for (int i =0; i < arrBtn.length; i++) {
           arrBtn[i].setText("");
           arrBtn[i].setIcon(null);
        }
    }
    

        

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtP2 = new javax.swing.JTextField();
        txtP1 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        lblFecha = new javax.swing.JLabel();
        btnReiniciar = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();
        txtFecha = new javax.swing.JTextField();
        txtHora = new javax.swing.JTextField();
        bnt1 = new javax.swing.JButton();
        bnt29 = new javax.swing.JButton();
        bnt22 = new javax.swing.JButton();
        bnt15 = new javax.swing.JButton();
        bnt43 = new javax.swing.JButton();
        bnt8 = new javax.swing.JButton();
        bnt36 = new javax.swing.JButton();
        bnt2 = new javax.swing.JButton();
        bnt3 = new javax.swing.JButton();
        bnt4 = new javax.swing.JButton();
        bnt5 = new javax.swing.JButton();
        bnt7 = new javax.swing.JButton();
        bnt9 = new javax.swing.JButton();
        bnt6 = new javax.swing.JButton();
        bnt10 = new javax.swing.JButton();
        bnt23 = new javax.swing.JButton();
        bnt16 = new javax.swing.JButton();
        bnt37 = new javax.swing.JButton();
        bnt30 = new javax.swing.JButton();
        bnt14 = new javax.swing.JButton();
        bnt11 = new javax.swing.JButton();
        bnt12 = new javax.swing.JButton();
        bnt13 = new javax.swing.JButton();
        bnt17 = new javax.swing.JButton();
        bnt24 = new javax.swing.JButton();
        bnt31 = new javax.swing.JButton();
        bnt38 = new javax.swing.JButton();
        bnt45 = new javax.swing.JButton();
        bnt18 = new javax.swing.JButton();
        bnt19 = new javax.swing.JButton();
        bnt20 = new javax.swing.JButton();
        bnt21 = new javax.swing.JButton();
        bnt25 = new javax.swing.JButton();
        bnt26 = new javax.swing.JButton();
        bnt27 = new javax.swing.JButton();
        bnt28 = new javax.swing.JButton();
        bnt32 = new javax.swing.JButton();
        bnt44 = new javax.swing.JButton();
        bnt35 = new javax.swing.JButton();
        bnt33 = new javax.swing.JButton();
        bnt34 = new javax.swing.JButton();
        bnt41 = new javax.swing.JButton();
        bnt49 = new javax.swing.JButton();
        bnt42 = new javax.swing.JButton();
        bnt48 = new javax.swing.JButton();
        bnt40 = new javax.swing.JButton();
        bnt39 = new javax.swing.JButton();
        bnt46 = new javax.swing.JButton();
        bnt47 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.red, java.awt.Color.red, java.awt.Color.red, java.awt.Color.red));

        jLabel1.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Jugador1");
        jLabel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));

        jLabel2.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Jugador2");
        jLabel2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));

        txtP2.setEditable(false);
        txtP2.setBackground(new java.awt.Color(0, 0, 0));
        txtP2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        txtP2.setForeground(new java.awt.Color(255, 255, 255));
        txtP2.setText("0");
        txtP2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));

        txtP1.setEditable(false);
        txtP1.setBackground(new java.awt.Color(0, 0, 0));
        txtP1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        txtP1.setForeground(new java.awt.Color(255, 255, 255));
        txtP1.setText("0");
        txtP1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));

        jLabel3.setBackground(new java.awt.Color(0, 0, 0));
        jLabel3.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Hora:");
        jLabel3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));

        lblFecha.setBackground(new java.awt.Color(0, 0, 0));
        lblFecha.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        lblFecha.setForeground(new java.awt.Color(255, 255, 255));
        lblFecha.setText("Fecha:");
        lblFecha.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));

        btnReiniciar.setBackground(new java.awt.Color(0, 0, 0));
        btnReiniciar.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        btnReiniciar.setForeground(new java.awt.Color(255, 255, 255));
        btnReiniciar.setText("Reiniciar");
        btnReiniciar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        btnReiniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReiniciarActionPerformed(evt);
            }
        });

        btnVolver.setBackground(new java.awt.Color(0, 0, 0));
        btnVolver.setFont(new java.awt.Font("Niagara Solid", 0, 18)); // NOI18N
        btnVolver.setForeground(new java.awt.Color(255, 255, 255));
        btnVolver.setText("Volver");
        btnVolver.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });

        txtFecha.setEditable(false);
        txtFecha.setBackground(new java.awt.Color(0, 0, 0));
        txtFecha.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        txtFecha.setForeground(new java.awt.Color(255, 255, 255));
        txtFecha.setText("0");
        txtFecha.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));

        txtHora.setEditable(false);
        txtHora.setBackground(new java.awt.Color(0, 0, 0));
        txtHora.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        txtHora.setForeground(new java.awt.Color(255, 255, 255));
        txtHora.setText("0");
        txtHora.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));

        bnt1.setBackground(new java.awt.Color(0, 0, 0));
        bnt1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt1ActionPerformed(evt);
            }
        });

        bnt29.setBackground(new java.awt.Color(0, 0, 0));
        bnt29.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt29ActionPerformed(evt);
            }
        });

        bnt22.setBackground(new java.awt.Color(0, 0, 0));
        bnt22.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt22ActionPerformed(evt);
            }
        });

        bnt15.setBackground(new java.awt.Color(0, 0, 0));
        bnt15.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt15ActionPerformed(evt);
            }
        });

        bnt43.setBackground(new java.awt.Color(0, 0, 0));
        bnt43.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt43.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt43ActionPerformed(evt);
            }
        });

        bnt8.setBackground(new java.awt.Color(0, 0, 0));
        bnt8.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt8ActionPerformed(evt);
            }
        });

        bnt36.setBackground(new java.awt.Color(0, 0, 0));
        bnt36.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt36ActionPerformed(evt);
            }
        });

        bnt2.setBackground(new java.awt.Color(0, 0, 0));
        bnt2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt2ActionPerformed(evt);
            }
        });

        bnt3.setBackground(new java.awt.Color(0, 0, 0));
        bnt3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt3ActionPerformed(evt);
            }
        });

        bnt4.setBackground(new java.awt.Color(0, 0, 0));
        bnt4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt4ActionPerformed(evt);
            }
        });

        bnt5.setBackground(new java.awt.Color(0, 0, 0));
        bnt5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt5ActionPerformed(evt);
            }
        });

        bnt7.setBackground(new java.awt.Color(0, 0, 0));
        bnt7.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt7ActionPerformed(evt);
            }
        });

        bnt9.setBackground(new java.awt.Color(0, 0, 0));
        bnt9.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt9ActionPerformed(evt);
            }
        });

        bnt6.setBackground(new java.awt.Color(0, 0, 0));
        bnt6.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt6ActionPerformed(evt);
            }
        });

        bnt10.setBackground(new java.awt.Color(0, 0, 0));
        bnt10.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt10ActionPerformed(evt);
            }
        });

        bnt23.setBackground(new java.awt.Color(0, 0, 0));
        bnt23.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt23ActionPerformed(evt);
            }
        });

        bnt16.setBackground(new java.awt.Color(0, 0, 0));
        bnt16.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt16ActionPerformed(evt);
            }
        });

        bnt37.setBackground(new java.awt.Color(0, 0, 0));
        bnt37.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt37.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt37ActionPerformed(evt);
            }
        });

        bnt30.setBackground(new java.awt.Color(0, 0, 0));
        bnt30.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt30ActionPerformed(evt);
            }
        });

        bnt14.setBackground(new java.awt.Color(0, 0, 0));
        bnt14.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt14ActionPerformed(evt);
            }
        });

        bnt11.setBackground(new java.awt.Color(0, 0, 0));
        bnt11.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt11ActionPerformed(evt);
            }
        });

        bnt12.setBackground(new java.awt.Color(0, 0, 0));
        bnt12.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt12ActionPerformed(evt);
            }
        });

        bnt13.setBackground(new java.awt.Color(0, 0, 0));
        bnt13.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt13ActionPerformed(evt);
            }
        });

        bnt17.setBackground(new java.awt.Color(0, 0, 0));
        bnt17.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt17ActionPerformed(evt);
            }
        });

        bnt24.setBackground(new java.awt.Color(0, 0, 0));
        bnt24.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt24ActionPerformed(evt);
            }
        });

        bnt31.setBackground(new java.awt.Color(0, 0, 0));
        bnt31.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt31ActionPerformed(evt);
            }
        });

        bnt38.setBackground(new java.awt.Color(0, 0, 0));
        bnt38.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt38ActionPerformed(evt);
            }
        });

        bnt45.setBackground(new java.awt.Color(0, 0, 0));
        bnt45.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt45.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt45ActionPerformed(evt);
            }
        });

        bnt18.setBackground(new java.awt.Color(0, 0, 0));
        bnt18.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt18ActionPerformed(evt);
            }
        });

        bnt19.setBackground(new java.awt.Color(0, 0, 0));
        bnt19.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt19ActionPerformed(evt);
            }
        });

        bnt20.setBackground(new java.awt.Color(0, 0, 0));
        bnt20.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt20ActionPerformed(evt);
            }
        });

        bnt21.setBackground(new java.awt.Color(0, 0, 0));
        bnt21.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt21ActionPerformed(evt);
            }
        });

        bnt25.setBackground(new java.awt.Color(0, 0, 0));
        bnt25.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt25ActionPerformed(evt);
            }
        });

        bnt26.setBackground(new java.awt.Color(0, 0, 0));
        bnt26.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt26ActionPerformed(evt);
            }
        });

        bnt27.setBackground(new java.awt.Color(0, 0, 0));
        bnt27.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt27ActionPerformed(evt);
            }
        });

        bnt28.setBackground(new java.awt.Color(0, 0, 0));
        bnt28.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt28ActionPerformed(evt);
            }
        });

        bnt32.setBackground(new java.awt.Color(0, 0, 0));
        bnt32.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt32ActionPerformed(evt);
            }
        });

        bnt44.setBackground(new java.awt.Color(0, 0, 0));
        bnt44.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt44.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt44ActionPerformed(evt);
            }
        });

        bnt35.setBackground(new java.awt.Color(0, 0, 0));
        bnt35.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt35ActionPerformed(evt);
            }
        });

        bnt33.setBackground(new java.awt.Color(0, 0, 0));
        bnt33.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt33ActionPerformed(evt);
            }
        });

        bnt34.setBackground(new java.awt.Color(0, 0, 0));
        bnt34.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt34ActionPerformed(evt);
            }
        });

        bnt41.setBackground(new java.awt.Color(0, 0, 0));
        bnt41.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt41.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt41ActionPerformed(evt);
            }
        });

        bnt49.setBackground(new java.awt.Color(0, 0, 0));
        bnt49.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt49.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt49ActionPerformed(evt);
            }
        });

        bnt42.setBackground(new java.awt.Color(0, 0, 0));
        bnt42.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt42.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt42ActionPerformed(evt);
            }
        });

        bnt48.setBackground(new java.awt.Color(0, 0, 0));
        bnt48.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt48.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt48ActionPerformed(evt);
            }
        });

        bnt40.setBackground(new java.awt.Color(0, 0, 0));
        bnt40.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt40ActionPerformed(evt);
            }
        });

        bnt39.setBackground(new java.awt.Color(0, 0, 0));
        bnt39.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt39.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt39ActionPerformed(evt);
            }
        });

        bnt46.setBackground(new java.awt.Color(0, 0, 0));
        bnt46.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt46.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt46ActionPerformed(evt);
            }
        });

        bnt47.setBackground(new java.awt.Color(0, 0, 0));
        bnt47.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.red, java.awt.Color.blue, java.awt.Color.red));
        bnt47.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt47ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(lblFecha, javax.swing.GroupLayout.DEFAULT_SIZE, 45, Short.MAX_VALUE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtHora, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtP2, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                                    .addComponent(txtP1)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btnVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnReiniciar, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(32, 32, 32))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(81, 81, 81)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(bnt8, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bnt1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bnt15, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bnt22, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bnt29, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bnt36, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bnt43, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(bnt16, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(bnt17, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(bnt18, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(bnt19, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(bnt20, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(bnt21, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(bnt2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt4, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt5, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt6, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(bnt9, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt10, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt11, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt12, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt13, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(bnt14, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(bnt7, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(bnt23, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt24, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt25, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt26, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt27, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(bnt30, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(bnt31, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(bnt32, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(bnt33, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(bnt44, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(bnt45, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(bnt46, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(bnt47, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(bnt34, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(bnt48, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(bnt37, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt38, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt39, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt40, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt41, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(bnt42, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(bnt35, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(bnt28, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(bnt49, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addContainerGap(117, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(bnt9, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                    .addComponent(lblFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel1)
                                                    .addComponent(txtP1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGap(7, 7, 7)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(txtHora, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(txtP2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGap(6, 6, 6)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addComponent(bnt1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(bnt7, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(bnt5, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(bnt4, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(bnt3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addComponent(bnt2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                .addComponent(bnt8, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                                .addGap(6, 6, 6)
                                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                    .addComponent(bnt14, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                    .addComponent(bnt10, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                    .addComponent(bnt11, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                    .addComponent(bnt12, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                    .addComponent(bnt13, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                                    .addComponent(bnt6, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(bnt15, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(bnt17, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(bnt18, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(bnt19, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(bnt20, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(bnt21, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addComponent(bnt16, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(bnt22, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(bnt23, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(bnt29, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(bnt24, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(bnt25, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(bnt26, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(bnt27, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(bnt28, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(bnt31, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(bnt32, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(bnt35, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(bnt33, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(bnt34, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addComponent(bnt30, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(bnt38, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(bnt42, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(bnt39, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(bnt40, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bnt36, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bnt37, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(bnt41, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bnt45, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bnt49, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bnt48, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bnt46, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bnt47, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bnt43, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bnt44, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnVolver)
                    .addComponent(btnReiniciar))
                .addGap(74, 74, 74))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnReiniciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReiniciarActionPerformed
        reiniciar();
    }//GEN-LAST:event_btnReiniciarActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    private void bnt1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt1ActionPerformed
       turno(bnt1);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt1ActionPerformed

    private void bnt29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt29ActionPerformed
       turno(bnt29);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt29ActionPerformed

    private void bnt22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt22ActionPerformed
        turno(bnt22);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt22ActionPerformed

    private void bnt15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt15ActionPerformed
        turno(bnt15);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt15ActionPerformed

    private void bnt43ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt43ActionPerformed
       turno(bnt43);
       ganador();
        Empata();
    }//GEN-LAST:event_bnt43ActionPerformed

    private void bnt8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt8ActionPerformed
        turno(bnt8);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt8ActionPerformed

    private void bnt36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt36ActionPerformed
       turno(bnt36);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt36ActionPerformed

    private void bnt2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt2ActionPerformed
        turno(bnt2);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt2ActionPerformed

    private void bnt3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt3ActionPerformed
        turno(bnt3);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt3ActionPerformed

    private void bnt4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt4ActionPerformed
        turno(bnt4);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt4ActionPerformed

    private void bnt5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt5ActionPerformed
        turno(bnt5);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt5ActionPerformed

    private void bnt7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt7ActionPerformed
        turno(bnt7);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt7ActionPerformed

    private void bnt9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt9ActionPerformed
        turno(bnt9);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt9ActionPerformed

    private void bnt6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt6ActionPerformed
        turno(bnt6);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt6ActionPerformed

    private void bnt10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt10ActionPerformed
        turno(bnt10);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt10ActionPerformed

    private void bnt23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt23ActionPerformed
        turno(bnt23);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt23ActionPerformed

    private void bnt16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt16ActionPerformed
        turno(bnt16);
       ganador();
     Empata();
    }//GEN-LAST:event_bnt16ActionPerformed

    private void bnt37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt37ActionPerformed
        turno(bnt37);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt37ActionPerformed

    private void bnt30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt30ActionPerformed
        turno(bnt30);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt30ActionPerformed

    private void bnt14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt14ActionPerformed
        turno(bnt14);
        Empata();
       ganador();
    }//GEN-LAST:event_bnt14ActionPerformed

    private void bnt11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt11ActionPerformed
        turno(bnt11);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt11ActionPerformed

    private void bnt12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt12ActionPerformed
        turno(bnt12);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt12ActionPerformed

    private void bnt13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt13ActionPerformed
        turno(bnt13);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt13ActionPerformed

    private void bnt17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt17ActionPerformed
        turno(bnt17);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt17ActionPerformed

    private void bnt24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt24ActionPerformed
        turno(bnt24);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt24ActionPerformed

    private void bnt31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt31ActionPerformed
        turno(bnt31);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt31ActionPerformed

    private void bnt38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt38ActionPerformed
        turno(bnt38);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt38ActionPerformed

    private void bnt45ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt45ActionPerformed
        turno(bnt45);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt45ActionPerformed

    private void bnt18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt18ActionPerformed
        turno(bnt18);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt18ActionPerformed

    private void bnt19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt19ActionPerformed
        turno(bnt19);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt19ActionPerformed

    private void bnt20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt20ActionPerformed
        turno(bnt20);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt20ActionPerformed

    private void bnt21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt21ActionPerformed
        turno(bnt21);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt21ActionPerformed

    private void bnt25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt25ActionPerformed
        turno(bnt25);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt25ActionPerformed

    private void bnt26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt26ActionPerformed
        turno(bnt26);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt26ActionPerformed

    private void bnt27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt27ActionPerformed
        turno(bnt27);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt27ActionPerformed

    private void bnt28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt28ActionPerformed
        turno(bnt28);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt28ActionPerformed

    private void bnt32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt32ActionPerformed
        turno(bnt32);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt32ActionPerformed

    private void bnt44ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt44ActionPerformed
        turno(bnt44);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt44ActionPerformed

    private void bnt35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt35ActionPerformed
        turno(bnt35);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt35ActionPerformed

    private void bnt33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt33ActionPerformed
        turno(bnt33);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt33ActionPerformed

    private void bnt34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt34ActionPerformed
        turno(bnt34);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt34ActionPerformed

    private void bnt41ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt41ActionPerformed
        turno(bnt41);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt41ActionPerformed

    private void bnt49ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt49ActionPerformed
        turno(bnt49);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt49ActionPerformed

    private void bnt42ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt42ActionPerformed
        turno(bnt42);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt42ActionPerformed

    private void bnt48ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt48ActionPerformed
        turno(bnt48);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt48ActionPerformed

    private void bnt40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt40ActionPerformed
        turno(bnt40);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt40ActionPerformed

    private void bnt39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt39ActionPerformed
        turno(bnt39);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt39ActionPerformed

    private void bnt46ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt46ActionPerformed
        turno(bnt46);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt46ActionPerformed

    private void bnt47ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt47ActionPerformed
        turno(bnt47);
       ganador();
       Empata();
    }//GEN-LAST:event_bnt47ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Juego7.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Juego7.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Juego7.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Juego7.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Juego7 dialog = new Juego7(new javax.swing.JDialog(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bnt1;
    private javax.swing.JButton bnt10;
    private javax.swing.JButton bnt11;
    private javax.swing.JButton bnt12;
    private javax.swing.JButton bnt13;
    private javax.swing.JButton bnt14;
    private javax.swing.JButton bnt15;
    private javax.swing.JButton bnt16;
    private javax.swing.JButton bnt17;
    private javax.swing.JButton bnt18;
    private javax.swing.JButton bnt19;
    private javax.swing.JButton bnt2;
    private javax.swing.JButton bnt20;
    private javax.swing.JButton bnt21;
    private javax.swing.JButton bnt22;
    private javax.swing.JButton bnt23;
    private javax.swing.JButton bnt24;
    private javax.swing.JButton bnt25;
    private javax.swing.JButton bnt26;
    private javax.swing.JButton bnt27;
    private javax.swing.JButton bnt28;
    private javax.swing.JButton bnt29;
    private javax.swing.JButton bnt3;
    private javax.swing.JButton bnt30;
    private javax.swing.JButton bnt31;
    private javax.swing.JButton bnt32;
    private javax.swing.JButton bnt33;
    private javax.swing.JButton bnt34;
    private javax.swing.JButton bnt35;
    private javax.swing.JButton bnt36;
    private javax.swing.JButton bnt37;
    private javax.swing.JButton bnt38;
    private javax.swing.JButton bnt39;
    private javax.swing.JButton bnt4;
    private javax.swing.JButton bnt40;
    private javax.swing.JButton bnt41;
    private javax.swing.JButton bnt42;
    private javax.swing.JButton bnt43;
    private javax.swing.JButton bnt44;
    private javax.swing.JButton bnt45;
    private javax.swing.JButton bnt46;
    private javax.swing.JButton bnt47;
    private javax.swing.JButton bnt48;
    private javax.swing.JButton bnt49;
    private javax.swing.JButton bnt5;
    private javax.swing.JButton bnt6;
    private javax.swing.JButton bnt7;
    private javax.swing.JButton bnt8;
    private javax.swing.JButton bnt9;
    private javax.swing.JButton btnReiniciar;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblFecha;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtHora;
    private javax.swing.JTextField txtP1;
    private javax.swing.JTextField txtP2;
    // End of variables declaration//GEN-END:variables
}
