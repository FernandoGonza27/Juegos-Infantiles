package ProyectoTerminado;

import java.util.ArrayList;

public class Jugadores {
    String nombre;
    String puntos;
    String fecha;
    String hora;
    public Jugadores() {
    }
    static ArrayList<Jugadores>Jugador=new ArrayList();
    static ArrayList<Jugadores>Jugador_list3=new ArrayList();
    public Jugadores(String nombre, String puntos,String fecha,String hora) {
        this.nombre = nombre;
        this.puntos = puntos;
        this.fecha = fecha;
        this.hora = hora;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPuntos() {
        return puntos;
    }

    public void setPuntos(String puntos) {
        this.puntos = puntos;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }
    
    
    public void  agrega (String nom,String puntos,String fecha,String hora){
        Jugadores objjuego;
        objjuego=new Jugadores();//Secrea objeto
            //Captura de valores
        objjuego.setNombre(nom);
        objjuego.setPuntos(puntos);
        objjuego.setFecha(fecha);
        objjuego.setHora(hora);
        //Captura de valores

        Jugador.add(objjuego);//Crear nodo para almacenar objeto
    }
    
    public void  agregaGanador (String nom,String puntos){
        Jugador_list3.clear();
        Jugadores objjuego;
        objjuego=new Jugadores();//Secrea objeto
            //Captura de valores
        objjuego.setNombre(nom);
        objjuego.setPuntos(puntos);
        
        Jugador_list3.add(objjuego);//Crear nodo para almacenar objeto}
        
    }
}
