
package ProyectoTerminado;
import static ProyectoTerminado.player.players_list;
import java.io.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import ProyectoTerminado.player;

public class files {
    
    static ArrayList<String>words_list = new ArrayList<String>();
    static ArrayList<String>words = new ArrayList<String>();
    static ArrayList<player>players = new ArrayList();
    static ArrayList<player>players_list2 = new ArrayList();
    public void read_lettersfile(){
        
        try{
            BufferedReader bf = new BufferedReader(new FileReader ("palabras.txt"));
            
            String bfRead;
            int i = 0;
            while ((bfRead = bf.readLine()) != null){
                String word = bfRead.toUpperCase();
                words_list.add(word);
                i++;
                
            }
        }catch(Exception e){System.out.println("NO hay");}
    }
    public void letters_games(){
        words.clear();
        int index = players_list.size()-1; 
        int cant_letters = players_list.get(index).getLetters();
        for (int i = 0;i<words_list.size();i++){
            
            String word = words_list.get(i);
            if (word.length() == cant_letters){
                words.add(word);
            }
        }
    }
    public void writeFile(){
        PrintWriter writer = null;
        copyarray();
        try {
            
            writer = new PrintWriter(new BufferedWriter(new FileWriter("players.txt",true)));
            
            for (int i = 0; i < players_list.size(); i++) {
                writer.println(players_list.get(i).getName() +"-"+players_list.get(i).getPoints());
                players_list.remove(i);
            }
            
            writer.close();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Error al escribir el archivo");
        }
        
    }
    public void readFile(){
        
        
        try {


            players.clear();
            BufferedReader reader = new BufferedReader(new FileReader("players.txt"));
            String s = new String();
            String userName;
            int points;
            while ((s = reader.readLine()) != null) {
                player player2 = new player();
                
                String[] data = s.split("-");
                userName = data[0];
                points = Integer.parseInt(data[1]);
                player2.setName(userName);
                player2.setPoints(points);
                players.add(player2);
                
            }
        
            
            reader.close();
        } catch (java.io.IOException e) {
            JOptionPane.showMessageDialog(null, "error al leer el archivo");
        }
    
    }
    protected void copyarray(){
        players_list2.clear();
        for (int i = 0;i<players_list.size();i++){
            players_list2.add(players_list.get(i));
            
        }
        
    }
}
